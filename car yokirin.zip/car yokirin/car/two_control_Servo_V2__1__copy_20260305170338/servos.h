#define SERVO_PIN 12
// ประกาศว่า servoTarget อยู่ไฟล์อื่น
extern volatile int servoTarget;

void initServos();
void Servo_do(float degree);
