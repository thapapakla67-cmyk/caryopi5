#include "encoder_driver.h"
#include "commands.h"
#include <ESP32Encoder.h>   // Install library!!!

ESP32Encoder leftEnc;
ESP32Encoder rightEnc;

void initEncoders() {
  leftEnc.attachHalfQuad(LEFT_ENC_PIN_A, LEFT_ENC_PIN_B);
  rightEnc.attachHalfQuad(RIGHT_ENC_PIN_A, RIGHT_ENC_PIN_B);
  resetEncoders();
}

long readEncoder(int i) {
  if (i == LEFT) return leftEnc.getCount();
  return rightEnc.getCount();
}

void resetEncoder(int i) {
  if (i == LEFT) leftEnc.clearCount();
  else rightEnc.clearCount();
}

void resetEncoders() {
  resetEncoder(LEFT);
  resetEncoder(RIGHT);
}
