#include "motor_driver.h"
#include "commands.h"

#define PWM_FREQ 30000
#define PWM_RES  8
#define MAX_PWM  255

// PWM channels
#define CH_LF 0
#define CH_LB 1
#define CH_RF 2
#define CH_RB 3

void initMotorController() {

  // setup PWM channels
  ledcSetup(CH_LF, PWM_FREQ, PWM_RES);
  ledcSetup(CH_LB, PWM_FREQ, PWM_RES);
  ledcSetup(CH_RF, PWM_FREQ, PWM_RES);
  ledcSetup(CH_RB, PWM_FREQ, PWM_RES);

  // attach pins
  ledcAttachPin(LEFT_MOTOR_FORWARD, CH_LF);
  ledcAttachPin(LEFT_MOTOR_BACKWARD, CH_LB);
  ledcAttachPin(RIGHT_MOTOR_FORWARD, CH_RF);
  ledcAttachPin(RIGHT_MOTOR_BACKWARD, CH_RB);

  pinMode(LEFT_MOTOR_ENABLE, OUTPUT);
  pinMode(RIGHT_MOTOR_ENABLE, OUTPUT);

  digitalWrite(LEFT_MOTOR_ENABLE, HIGH);
  digitalWrite(RIGHT_MOTOR_ENABLE, HIGH);

  // stop motors
  ledcWrite(CH_LF, 0);
  ledcWrite(CH_LB, 0);
  ledcWrite(CH_RF, 0);
  ledcWrite(CH_RB, 0);
}

void setMotorSpeed(int i, int spd) {

  bool reverse = false;

  if (spd < 0) {
    spd = -spd;
    reverse = true;
  }

  spd = constrain(spd, 0, MAX_PWM);

  if (i == LEFT) {

    if (!reverse) {
      ledcWrite(CH_LF, spd);
      ledcWrite(CH_LB, 0);
    } 
    else {
      ledcWrite(CH_LF, 0);
      ledcWrite(CH_LB, spd);
    }

  } 
  else {

    if (!reverse) {
      ledcWrite(CH_RF, spd);
      ledcWrite(CH_RB, 0);
    } 
    else {
      ledcWrite(CH_RF, 0);
      ledcWrite(CH_RB, spd);
    }

  }
}

void setMotorSpeeds(int leftSpeed, int rightSpeed) {

  setMotorSpeed(LEFT, rightSpeed);
  setMotorSpeed(RIGHT, leftSpeed);

}
