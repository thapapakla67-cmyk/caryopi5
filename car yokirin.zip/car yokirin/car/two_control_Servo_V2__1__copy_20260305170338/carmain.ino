#define BAUDRATE 115200

#include <string.h>
#include "commands.h"
#include "motor_driver.h"
#include "encoder_driver.h"
#include "servos.h"

int arg = 0;
int argIndex = 0;
char chr;
char cmd;
char argv1[16];
char argv2[16];
long arg1;
long arg2;

void resetCommand() {
    cmd = 0;
    arg = 0;
    argIndex = 0;
    arg1 = 0;
    arg2 = 0;
    memset(argv1, 0, sizeof(argv1));
    memset(argv2, 0, sizeof(argv2));
}

void runCommand() {

    arg1 = atol(argv1);
    arg2 = atol(argv2);

    switch (cmd) {

        case GET_BAUDRATE:
            Serial.println(BAUDRATE);
        break;

        case READ_ENCODERS:
            Serial.print(readEncoder(LEFT));
            Serial.print(" ");
            Serial.println(readEncoder(RIGHT));
        break;

        case RESET_ENCODERS:
            resetEncoders();
            Serial.println("OK");
        break;

        case MOTOR_RAW_PWM:
            setMotorSpeeds(arg1, arg2);
            Serial.println("OK");
        break;

        case SERVO_MOTOR:
            Servo_do(arg2);
            Serial.println("OK");
        break;

        default:
            Serial.println("Invalid Command");
        break;
    }
}

void setup() {

    Serial.begin(BAUDRATE);

    initMotorController();
    initEncoders();
    initServos();
}

void loop() {

    while (Serial.available() > 0) {

        chr = Serial.read();

        if (chr == '\r' || chr == '\n') {

            if (arg == 1) argv1[argIndex] = '\0';
            else if (arg == 2) argv2[argIndex] = '\0';

            if (cmd != 0) {
                runCommand();
            }

            resetCommand();
        }

        else if (chr == ' ') {

            if (arg == 0) {
                arg = 1;
            }

            else if (arg == 1) {
                argv1[argIndex] = '\0';
                arg = 2;
                argIndex = 0;
            }

            continue;
        }

        else {

            if (arg == 0) {
                cmd = chr;
            }

            else if (arg == 1 && argIndex < sizeof(argv1) - 1) {
                argv1[argIndex++] = chr;
            }

            else if (arg == 2 && argIndex < sizeof(argv2) - 1) {
                argv2[argIndex++] = chr;
            }
        }
    }
}
